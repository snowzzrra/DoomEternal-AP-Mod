# Archipelago Logo — Manual Import Preparation Report

Deterministic conversion of the shared Archipelago logo source asset into a
single-material OBJ + texture atlas suitable for the DOOM Eternal Model
Importer. No redesign, recoloring, simplification, or transform was applied.

## 1. Source Integrity

| File | SHA-256 | Verified |
|---|---|---|
| ArchipelagoLogo.obj | `936ce06c14def1c3ab138e1713553c9afe8e966b0e281ede7a1105b67298a114` | ✅ match |
| ArchipelagoLogo.mtl | `a8651a3407f3382ebbc4445599f458b69c3af809af9350a6bfab63653bca492e` | ✅ match |
| ArchipelagoLogo.blend | `3551789f76ff521cb45bb54facf767eb41ca4b430b4d627f6d06ba11419f6f54` | ✅ match |

Originals were opened read-only and were **not modified**.

## 2. Output File Hashes

| File | SHA-256 |
|---|---|
| ArchipelagoLogo_prepared.obj | `ab6a1f3d8fb833070889c80ef800a8ea9f55a1aa9dc905fb4599df32e5f9c659` |
| ArchipelagoLogo_prepared.mtl | `803221b0dbc9fff8d1789fbb114a6542b29aaecac000970b2535d68d87b9d76a` |
| archipelago_logo_atlas.png | `a25bb8b630dafe0dd4a5ad2863fa4ad41296277cf63818c4a7a2b4c1712b1a3a` |
| archipelago_logo_atlas_direct_kd.png (diagnostic only) | `af656a1f1cd34ae8f953f96262526869ae0e3b280ead771504377acf823947b2` |
| archipelago_logo_atlas_source.tga | `6e76b08e7e3e6dfb318b9ea80791a7ea15ed47de848912843cb3967246a6db3f` |

## 3. Source vs. Prepared Structure

| Metric | Source | Prepared |
|---|---|---|
| Vertex count | 5,964 | 5,964 (identical, index-for-index) |
| Source face count | 6,144 (384 tris + 5,760 quads) | — |
| Prepared triangle count | — | 11,904 (all quads split into 2 tris each; no other topology change) |
| Connected components | 6 | 6 |
| Material count | 6 (`Material.001`–`Material.006`) | 1 (`archipelago_logo`) |
| Bounding box (min) | (-0.300250, -0.818465, -0.898095) | (-0.300250, -0.818465, -0.898095) |
| Bounding box (max) | (0.300250, 0.818465, 0.898095) | (0.300250, 0.818465, 0.898095) |
| Triangulation changed face count? | — | Yes — expected, spec permits triangulation "if required for importer compatibility." No geometry, vertex position, normal, or topology was otherwise altered; each quad became two triangles sharing its original diagonal. |

## 4. Transform Confirmation

No rotation, translation, or scale was applied. Vertex and normal arrays were
copied verbatim from the source OBJ (byte-identical positions, confirmed by
direct list comparison). Only UV coordinates were remapped (see §6); vertex
and normal data are untouched.

## 5. Canonical Atlas Colors

Kd values were treated as Blender linear color and converted to sRGB using
the standard piecewise transfer function.

| Material | Linear Kd | sRGB float | sRGB 8-bit |
|---|---|---|---|
| Material.001 | 0.590615, 0.300544, 0.539480 | 0.792155, 0.584314, 0.760785 | 202, 149, 194 |
| Material.002 | 0.701098, 0.351533, 0.205079 | 0.854900, 0.627451, 0.490196 | 218, 160, 125 |
| Material.003 | 0.181163, 0.208637, 0.508881 | 0.462744, 0.494118, 0.741176 | 118, 126, 189 |
| Material.004 | 0.846868, 0.775823, 0.283149 | 0.929409, 0.894118, 0.568628 | 237, 228, 145 |
| Material.005 | 0.590616, 0.181164, 0.223228 | 0.792155, 0.462745, 0.509804 | 202, 118, 130 |
| Material.006 | 0.177887, 0.533277, 0.177889 | 0.458822, 0.756863, 0.458824 | 117, 193, 117 |

All computed 8-bit values match the expected approximate values given in the
task spec exactly. Full float precision was used internally for the
conversion; only the final atlas pixels are quantized to 8-bit.

The diagnostic atlas (`archipelago_logo_atlas_direct_kd.png`) uses the raw
linear Kd values directly (×255, rounded, no gamma correction) and is
**not** referenced by the prepared MTL — it exists only for visual
comparison against the gamma-correct canonical atlas.

## 6. UV Tile Assignment

256×256 atlas, 2 columns × 3 rows. Column split at x=128 (two 128px-wide
columns); row split at y=85/171 (rows of 85, 86, 85 px). All tiles carry an
8px inset from every boundary for the actual UV footprint, leaving a solid
color margin to prevent mip-map bleed into neighboring tiles.

| Material | Grid position | Pixel rect (x0,y0,x1,y1) |
|---|---|---|
| Material.001 | top-left | (0, 0, 128, 85) |
| Material.002 | top-right | (128, 0, 256, 85) |
| Material.003 | middle-left | (0, 85, 128, 171) |
| Material.004 | middle-right | (128, 85, 256, 171) |
| Material.005 | bottom-left | (0, 171, 128, 256) |
| Material.006 | bottom-right | (128, 171, 256, 256) |

**UV convention note:** standard image/UV mapping was used, where image row
0 (top of the PNG as viewed normally) corresponds to UV `v = 1`. All 6
components use an identical underlying UV sphere-unwrap (confirmed
programmatically — all six materials reference the same 1087-entry UV set,
each already spanning [0,1]×[0,1]). Each material's UVs were normalized to
its own bounding box (defensive; already ~[0,1]) and remapped into its
assigned tile's inset sub-rectangle. 6,522 new `vt` entries were generated
(6 materials × up to 1,087 UV values each, deduplicated per
material/original-UV pair).

Post-remap validation (programmatic) confirmed 0 UV coordinates fall outside
their assigned tile's inset boundary — no cross-tile bleed is possible.

## 7. Validation Results

All required checks were run programmatically against the output files:

1. ✅ OBJ loads/parses successfully
2. ✅ MTL loads/parses successfully
3. ✅ OBJ references `ArchipelagoLogo_prepared.mtl`
4. ✅ OBJ uses exactly one material (`archipelago_logo`)
5. ✅ No `Material.00X` references remain
6. ✅ UVs present (6,522 `vt` entries)
7. ✅ Normals present (4,358 `vn` entries, unchanged from source)
8. ✅ Six disconnected geometric components remain
9. ✅ Source and prepared bounding boxes equal (identical, zero tolerance needed)
10. ✅ Source and prepared vertex positions equal index-for-index
11. ✅ No rotation, translation, or scaling applied
12. ✅ Every component's UVs remain entirely inside its assigned atlas tile
13. ✅ Canonical PNG is exactly 256×256 RGBA
14. ✅ TGA is exactly 256×256, uncompressed (TGA image_type=2, verified at header level)
15. ✅ All atlas pixels are opaque (alpha channel uniformly 255)
16. ✅ Diagnostic atlas is not referenced by the MTL
17. ✅ No missing texture path (`map_Kd archipelago_logo_atlas.png` resolves within the prepared directory)
18. ✅ ZIP extracts and OBJ loads using only files inside it (verified below)

## 8. Warnings / Limitations

- **`ArchipelagoLogo_prepared.blend` was not produced.** Blender is not
  available in this processing environment (not installed, and not
  installable — `blender.org` / package sources for it are outside the
  network allowlist here). Per the task spec, this file is optional
  ("useful but not a substitute for the required OBJ, MTL and atlas").
  The required OBJ/MTL/atlas/TGA/report/zip deliverables were all produced
  and validated. If a Blender-compatible environment is available on your
  end, the same atlas (`archipelago_logo_atlas.png`) and prepared OBJ can be
  imported into Blender and packed into a `.blend` following the same
  single-material/no-unrelated-reference constraints.
- Triangulation was applied (5,760 quads → 11,520 tris, plus the original
  384 tris = 11,904 total) since the target is a GUI-based game-engine
  importer; this is an allowed, spec-anticipated topology change and does
  not alter vertex positions, normals, or silhouette.
- No `map_Kd` or bump texture existed in the original MTL, consistent with
  the expected source structure.
- This task only prepares the source OBJ/MTL/atlas for the **manual**
  DOOM Eternal Model Importer step. No LWO or streamdb binary payload was
  fabricated — those must be produced by running the actual Model Importer
  tool against `ArchipelagoLogo_prepared.obj`.

## 9. DOOM Eternal Manual Import Handoff

- **Model path:** `art/pickups/archipelago_logo.lwo`
- **Material2 intended name:** `art/pickups/archipelago_logo`
- **Model Importer input:** `ArchipelagoLogo_prepared.obj` (+ its `.mtl` and
  `archipelago_logo_atlas.png`, all in this `prepared/` directory)

The Model Importer must still be run (manually, in its GUI) to produce:
- the resource LWO payload
- the matching streamdb id# payload

Those binary outputs are outside the scope of this preparation task and were
not fabricated here.
